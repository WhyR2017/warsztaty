#-------------------- LIBS --------------------
#- instalacja pakietow
# install.packages('igraph')
# install.packages('visNetwork')
# install.packages('Matrix')
#- ladowania pakietow
library('igraph')
library('visNetwork')
library('Matrix')
#- IGRAPH
#- pakiet potrzebny do operacji na grafach
#- VISNETWORK
#- pakiet potrzebny do wizualizacji grafów
#- MATRIX
#- pakiet wprowadzajacy macierze rzadkie
#----------------------------------------------
#- strona z danymi MovieLens
# https://grouplens.org/datasets/movielens/
#- sekcja older dataset 
#- sciezka dostepu do danych
#setwd('C:/main/projects/whyR/SNAiR/snairShiny/data/ml-100k/ml-100k/')
#system.time({

setwd('E:/main/projects/whyR/SNAiR/snairShiny/data/ml-100k/ml-100k/')
#- wczytanie listy krawedzi
D <- read.table('u.data')
colnames(D) <- c('user','item','rating','time')
head(D)
#- przesuniecie identyfikatorow filmow
D[,2] <- D[,2] + max(D[,1])
#- wczytanie meta danych dla przedmiotow
item <- read.delim('u.item', header = FALSE)
#- wczytanie meta danych gatunkow filmowych
genre <- read.delim('u.genre', sep = '|', header = FALSE)
#- ustalenie formatu zmiennej z gatunkiem filmu
genre[,1] <- as.character(genre[,1])
#- poprawienie identyfikatora gatunku
genre[,2] <- genre[,2]+1
#- wczytanie informacji o uzytkowniku
user <- read.table('u.user', sep = '|')
#- preprocessing informacji o filmach
item1 <- strsplit(as.character(item[,1]),split = "|", fixed = TRUE)
#- pozyskanie nazwy filmu
item.names <- sapply(item1, function(x){x[2]})
#- pozyskanie gatunku filmu
item.genre.tmp <- lapply(item1, function(x){as.numeric(x[6:24])})
item.genre <- sapply(item.genre.tmp, function(x){paste0(genre[,1][match(which(x==1),genre[,2])], collapse = '|')})
#-- utworzenie grafu z listy krawedzi --------------
G.Movielens <- graph_from_edgelist(as.matrix(D[,1:2]), directed = TRUE)
#------ nalozenie atrybutow na wierzcholki
#- przypisanie typu klasy grafu dwudzielnego
V(G.Movielens)$type <- FALSE
V(G.Movielens)$type[sort(unique(D[,2]))] <- TRUE
#- przypisanie nazw wierzcholkow
V(G.Movielens)$title <- 0
V(G.Movielens)$title[which(V(G.Movielens)$type == FALSE)] <- apply(user,1,function(x){paste(x[2:4], collapse = '|')})
V(G.Movielens)$title[which(V(G.Movielens)$type == TRUE)] <- item.names
#- przypisanie gatunku do filmu
V(G.Movielens)$genre <- ""
V(G.Movielens)$genre[which(V(G.Movielens)$type == TRUE)] <- item.genre
#-przypisanie ratingu do krawedzi
E(G.Movielens)$weight <- as.numeric(D[,3])
#-- analiza skupien przy uzyciu algorytmu Louvain
clust <- cluster_louvain(as.undirected(G.Movielens), weights = E(G.Movielens)$weight)
#- modularność
modularity(clust)
#- wyliczenie
clustRes.lst <- lapply(1:max(membership(clust)), function(i){
  #-- obiekty tymczasowe
  genre.tmp <- data.frame(x = as.character(genre[,1]),0)
  role.tmp <- data.frame(x = as.character(unique(user[,4])),0)
  sex.tmp <- data.frame(x = as.character(unique(user[,3])),0)
  #-- podgraf dla i-tego skupienia
  G.sub <- induced_subgraph(G.Movielens, v = which(membership(clust) == i))
  #- informacje o uzytkownikach w wybranym podgrafie
  sub.user <- V(G.sub)$title[which(V(G.sub)$type == FALSE)]
  sub.user.attr <- strsplit(sub.user, split = '|', fixed = TRUE)
  #- wiek
  user.age <- mean(sapply(sub.user.attr,function(x){as.numeric(x[1])}))
  #- plec
  user.sex <- table(sapply(sub.user.attr,function(x){x[2]}))
  #- zajecie
  user.role <- table(sapply(sub.user.attr,function(x){x[3]}))
  #- informacje o filmach w wybranym podgrafie
  sub.item <- V(G.sub)$genre[which(V(G.sub)$type == TRUE)]
  #- gatunki filmow w podgrafie
  item.genre <- table(unlist(strsplit(sub.item, split = '|', fixed = TRUE)))
  #- przypisanie wynikow do obiektow tymczasowych
  genre.tmp[match(names(item.genre),genre.tmp[,1]),2] <- item.genre
  role.tmp[match(names(user.role),role.tmp[,1]),2] <- user.role
  sex.tmp[match(names(user.sex),sex.tmp[,1]),2] <- user.sex
  #- return
  list(user.age, genre.tmp, role.tmp,  sex.tmp)
})
#- agregacja wynikow i przypisanie nazw wlasnosci wierzcholkow
age.clust <- sapply(clustRes.lst,function(x){x[[1]]})
genre.clust <- sapply(clustRes.lst,function(x){x[[2]][,2]})
rownames(genre.clust) <- as.character(genre[,1])
role.clust <- sapply(clustRes.lst,function(x){x[[3]][,2]})
rownames(role.clust) <- as.character(unique(user[,4]))
sex.clust <- sapply(clustRes.lst,function(x){x[[4]][,2]})
rownames(sex.clust) <- as.character(unique(user[,3]))

#- wyliczenie udzialu kazdego gatunku filmowego w poszczegolnych skupieniach
genre.clust <- genre.clust*(1/rowSums(genre.clust))
#- wyliczenie udzialu kazdego zajecia w poszczegolnych skupieniach
role.clust <- role.clust*(1/rowSums(role.clust))

#- wyliczenie udzialu plci w poszczegolnych skupieniach
sex.clust <- sex.clust*(1/rowSums(sex.clust))

#- wykresy
par(mfrow = c(2,2))
barplot(t(genre.clust), las = 2, col = rainbow(max(membership(clust))))
barplot(t(role.clust), las = 2, col = rainbow(max(membership(clust))))
barplot(t(sex.clust), las = 2, col = rainbow(max(membership(clust))))
plot(age.clust, type = 'b',pch = 19, cex = 3, col = rainbow(max(membership(clust))))

#- sortowanie wlasnosci wierzcholkow wedlug udzialu dla kazdego skupienia i przypisanie do tabeli
genre.DF <- sapply(1:max(membership(clust)),function(i){
  rownames(genre.clust)[order(genre.clust[,i], decreasing = TRUE)]
})
role.DF <- sapply(1:max(membership(clust)),function(i){
  rownames(role.clust)[order(role.clust[,i], decreasing = TRUE)]
})  

#- 1) dla kazdego skupienia wybiore jednego uczestnika, ktory ma najmniejsza liczbe ratingow
#- 2) dla filmu przez niego nie ocenionych policze srednie oceny pozostalych uczestnikow
#- 3) wybranemu w 1) uczestnikowi zaproponuje film o najwyzszym srednim ratingu
#- minimalna liczba uzytkownikow w glosowaniu
min.votes <- 20
#- predykcja i rekomendacja
recommendation <- lapply(1:max(membership(clust)), function(i){
  #- podgraf dla i-tego skupienia
  G.sub <- induced_subgraph(G.Movielens, v = which(membership(clust) == i))
  #- wierzcholki bedace uzytkownikami
  sub.user.vs <- which(V(G.sub)$type == FALSE)
  #- uzytkownik o najmniejszej liczbie ocen
  min.sub.user.v <- sub.user.vs[which.min(degree(G.sub, sub.user.vs))]
  #- ocenione przez niego filmy
  items.rated <- neighbors(G.sub,min.sub.user.v,1)
  #- nie ocenione przez niego filmy
  items.not.rated <- which(V(G.sub)$type == TRUE)[which(is.na(match(which(V(G.sub)$type == TRUE),items.rated)))]
  #- predykcja ratingu dla nie ocenionych filmow
  mean.rating <- sapply(items.not.rated, function(x){
    ratings <- incident(G.sub,x)$weight
    if(length(ratings)>= min.votes){
      mean(ratings)
    }else{
      0
    }
  })
  #- rekomendowany film
  if(length(mean.rating) > 0 && max(mean.rating) > 0){
    recom.item <- items.not.rated[which.max(mean.rating)]
    recom <- list(V(G.sub)$title[recom.item],V(G.sub)$genre[recom.item])
  }else{
    recom <- NULL
  }
  #- dane uzytkownika
  user <- list(V(G.sub)$title[min.sub.user.v],V(G.sub)$title[items.rated],V(G.sub)$genre[items.rated])
  list(user, recom)
})



#})

