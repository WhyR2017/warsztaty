#-- libs
library('visNetwork')
library('igraph')
library('DT')
shinyServer(function(input, output, clientData, session){
  #-- PLOTS
  #-- intro05
  output$graphDef <- renderVisNetwork({
    #- wybrana liczba wierzchołkow
    ver.cnt <- as.numeric(input$graphDef_ver)
    #- wybrana liczba krawedzi
    edg.cnt <- as.numeric(input$graphDef_edg)
    #- sprawdzenie czy nie wybrano wiecej krawedzi niz to mozliwe
    if((ver.cnt*(ver.cnt-1)/2)<edg.cnt)
      edg.cnt <- (ver.cnt*(ver.cnt-1)/2)
    
    #--------------------------------------------------#
    #--------------------- R CODE ---------------------#
    # ver.cnt - wybrana liczba wierzchołkow
    # edg.cnt - wybrana liczba krawedzi
    visIgraph(sample_gnm(ver.cnt, edg.cnt, directed = FALSE, loops = FALSE), smooth = TRUE) %>%
      visOptions(highlightNearest = TRUE)
    #--------------------------------------------------#
    #--------------------------------------------------#
    
  })
  #output$graphDef_txt <- renderText({
  #   paste('visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)',sep = '\n')
  # })
  #-- grafy05
  graphDescObj <- reactive({
    ver.cnt <- as.numeric(input$graphDesc_ver)
    edg.cnt <- as.numeric(input$graphDesc_edg)

    if((ver.cnt*(ver.cnt-1)/2)<edg.cnt)
      edg.cnt <- (ver.cnt*(ver.cnt-1)/2)
    
    sample_gnm(ver.cnt, edg.cnt, directed = as.logical(as.numeric(input$graphDesc_ifDirected)),
               loops = as.logical(as.numeric(input$graphDesc_ifLoops)))
  })
  output$graphDesc <- renderVisNetwork({
    G <- graphDescObj()
    visIgraph(G, smooth = TRUE) %>%
      visOptions(highlightNearest = TRUE)
  })
  #-- macierz sasiedztwa
  output$graphDesc_mat <- DT::renderDataTable(options = list(dom = 't', pageLength = 20), selection = 'none',{
    G <- graphDescObj()
    G.mat <- as.matrix(as_adj(graphDescObj(), type = 'both'))
    
    colnames(G.mat) <- 1:length(V(G))
    rownames(G.mat) <- 1:length(V(G))
    G.mat
  })
  #-- lista krawedzi
  output$graphDesc_edgLst <- DT::renderDataTable(options = list(dom = 't', pageLength = 150), selection = 'none',{
    G <- graphDescObj()
    G.mat <- as.matrix(as_edgelist(graphDescObj()))
    
    colnames(G.mat) <- c('From','To')
    rownames(G.mat) <- 1:length(E(G))
    G.mat
  })
  #-------- random graph
  graphRandomObj <- reactive({
    ver.cnt <- as.numeric(input$graphRandom_ver)
    edg.cnt <- as.numeric(input$graphRandom_edg)
    
    if((ver.cnt*(ver.cnt-1)/2)<edg.cnt)
      edg.cnt <- (ver.cnt*(ver.cnt-1)/2)
    
    sample_gnm(ver.cnt, edg.cnt, directed = FALSE,
               loops = FALSE)
  })
  output$graphRandom <- renderVisNetwork({
    G <- graphRandomObj()
    visIgraph(G, smooth = TRUE) %>%
      visOptions(highlightNearest = TRUE)
  })
  output$graphRandom_txt <- renderText({
    paste(
    'sample_gnm(sample_gnm(n, m, directed = FALSE, loops = FALSE))',
    'sample_gnp(n, p, directed = FALSE, loops = FALSE)'
    , sep = '\n')
  })
  output$graphRandomDegHist <- renderPlot({
    G <- graphRandomObj()
    hist(degree(G), col = 'lightblue')
  })
  #-------- small-world graph
  graphSmallWorldObj <- reactive({
    ver.cnt <- as.numeric(input$graphSmallWorld_ver)
    neigh.val <- as.numeric(input$graphSmallWorld_neigh)
    rewire.prob <- as.numeric(input$graphSmallWorld_rewire)

    sample_smallworld(1, ver.cnt, neigh.val,rewire.prob)
  })
  output$graphSmallWorld <- renderVisNetwork({
    G <- graphSmallWorldObj()
    visIgraph(G, smooth = TRUE) %>%
      visOptions(highlightNearest = TRUE)
  })
  output$graphSmallWorld_txt <- renderText({
    paste(
    'sample_smallworld(dim, size, nei, p, loops = FALSE, multiple = FALSE)'
    , sep = '\n')
  })
  output$graphSmallWorldDegHist <- renderPlot({
    G <- graphSmallWorldObj()
    hist(degree(G), col = 'lightblue')
  })
  #-------- Barbasi graph
  graphPAObj <- reactive({
    ver.cnt <- as.numeric(input$graphPA_ver)
    power.val <- as.numeric(input$graphPA_power)
    edg.cnt <- as.numeric(input$graphPA_edg)

    sample_pa(n=ver.cnt, power = power.val, m = edg.cnt)
  })
  output$graphPA<- renderVisNetwork({
    G <- graphPAObj()
    visIgraph(G, smooth = TRUE) %>%
      visOptions(highlightNearest = TRUE)
  })
  output$graphPA_txt <- renderText({
    paste(
    'sample_pa(n, power = 1, m = NULL, out.dist = NULL, out.seq = NULL,',
    'out.pref = FALSE, zero.appeal = 1, directed = TRUE,',
    'algorithm = c("psumtree", "psumtree-multiple", "bag"), start.graph = NULL)'
    , sep = '\n')
  })
  output$graphPADegHist <- renderPlot({
    G <- graphPAObj()
    hist(degree(G), col = 'lightblue')
  })
  #-------- bipartite graph
  graphBipartiteObj <- reactive({
    ver1class.cnt <- as.numeric(input$graphBipartite_1class)
    ver2class.cnt <- as.numeric(input$graphBipartite_2class)
    edg.cnt <- as.numeric(input$graphBipartite_edg)
    
    if((ver1class.cnt*ver2class.cnt)<edg.cnt)
      edg.cnt <- ver1class.cnt*ver2class.cnt
    
    sample_bipartite(ver1class.cnt, ver2class.cnt, type = 'gnm', m = edg.cnt)
  })
  output$graphBipartite <- renderVisNetwork({
    G <- graphBipartiteObj()
    if(input$graphBipartite_ifCol == '1'){
      kol <- rep('purple', length(V(G)))
      kol[which(vertex_attr(G)$type == TRUE)] <- "orange"
      V(G)$color <- kol
    }
    visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)
  })
  output$graphBipartite_txt <- renderText({
    paste(
    'sample_bipartite(n1, n2, type = c("gnp", "gnm"), p, m, directed = FALSE,',
    'mode = c("out", "in", "all"))'
    , sep = '\n')
  })
  output$graphBipartiteDegHist <- renderPlot({
    G <- graphBipartiteObj()
    hist(degree(G), col = 'lightblue')
  })
  #-------- citation graph
  graphCiteObj <- reactive({
    ver.cnt <- as.numeric(input$graphCite_ver)
    edg.cnt <- as.numeric(input$graphCite_edg)
    G <- make_full_citation_graph(ver.cnt)
    if(length(E(G)) < edg.cnt)
      edg.cnt <- length(E(G))
    
    G <- delete.edges(G, sample(1:length(E(G)),length(E(G)) - edg.cnt))
  })
  output$graphCite <- renderVisNetwork({
    G <- graphCiteObj()
    visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)
  })
  output$graphCite_txt <- renderText({
    paste(
    'G <- make_full_citation_graph(n, directed = TRUE)',
    'delete.edges(G, sample(1:length(E(G)),length(E(G)) - edg.cnt))'
    , sep = '\n')
  })
  output$graphCiteDegHist <- renderPlot({
    G <- graphCiteObj()
    hist(degree(G), col = 'lightblue')
  })
  #-------- cluster graph
  graphClustObj <- reactive({
    clust.cnt <- as.numeric(input$graphClust_clust)
    clustVer.cnt <- as.numeric(input$graphClust_ver)
    edg.prob <- as.numeric(input$graphClust_edgProb)
    edgBet.cnt <- as.numeric(input$graphClust_edgBetCnt)
    
    sample_islands(clust.cnt, clustVer.cnt, edg.prob,  edgBet.cnt)
  })
  output$graphClust <- renderVisNetwork({
    G <- graphClustObj()
    if(input$graphClust_ifCol == '1'){
      kol <- as.numeric(cluster_louvain(G)$membership)
      V(G)$color <- kol
    }
    
    visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)
  })
  output$graphClust_txt <- renderText({
    paste(
    'sample_islands(islands.n, islands.size, islands.pin, n.inter)'
    , sep = '\n')
  })
  output$graphClustDegHist <- renderPlot({
    G <- graphClustObj()
    hist(degree(G), col = 'lightblue')
  })
  #-------- tree graph
  graphTreeObj <- reactive({
    ver.cnt <- as.numeric(input$graphTree_ver)
    ver.deg <- as.numeric(input$graphTree_deg)
    make_tree(ver.cnt, ver.deg)
  })
  output$graphTree <- renderVisNetwork({
    G <- graphTreeObj()

    visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)
  })
  output$graphTree_txt <- renderText({
    paste(
    'make_tree(n, children = 2, mode = c("out", "in", "undirected"))'
    , sep = '\n')
  })
  output$graphTreeDegHist <- renderPlot({
    G <- graphTreeObj()
    hist(degree(G), col = 'lightblue')
  })
  
  #-------- tasks Graph
  graphTaskObj <- reactive({
    ver.cnt <- as.numeric(input$graphTask_ver)
    edg.cnt <- as.numeric(input$graphTask_edg)
    prob.val <- as.numeric(input$graphTask_prob)
    sample_smallworld(1,ver.cnt, edg.cnt,prob.val, multiple = TRUE,loops = TRUE)
  })
  output$graphTask <- renderVisNetwork({
    G <- graphTaskObj()
    visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)
  })
  output$graphTask_txt <- renderText({
    ver.cnt <- as.numeric(input$graphTask_ver)
    edg.cnt <- as.numeric(input$graphTask_edg)
    prob.val <- as.numeric(input$graphTask_prob)
    paste(
    paste0('sample_smallworld(1,',ver.cnt,',', edg.cnt,',',prob.val,', multiple = TRUE,
           loops = TRUE)'),
           'visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)',
           sep = '\n')
    
  })
  #------- tasks: degree distribution
  output$degree_txt <- renderText({
    paste(
    'Kod',
    'degree(graph, v = V(graph), mode = c("all", "out", "in", "total"), loops = TRUE, normalized = FALSE)',
    '\n',
    'Wynik',
    paste0(degree(graphTaskObj()), collapse = ' ')
    ,'\n',
    'Kod',
    'degree_distribution(graph, cumulative = FALSE, ...)',
    '\n',
    'Wynik',
    paste0(degree_distribution(graphTaskObj()), collapse = ' ')
    ,sep = '\n')
  })
  output$degree_txt1 <- renderText({
    if(!is.null(graphDataVer())){
    paste(
      'Kod',
      'degree(graph, v = V(graph), mode = c("all", "out", "in", "total"), loops = TRUE, normalized = FALSE)',
      '\n',
      'Wynik',
      paste0(degree(graphDataVer()), collapse = ' ')
      ,sep = '\n')
    }else{
      paste(
        'Kod',
        'degree(graph, v = V(graph), mode = c("all", "out", "in", "total"), loops = TRUE, normalized = FALSE)'
        ,sep = '\n')        
    }
  })
  #------- tasks: mean distance
  output$meanDist_txt <- renderText({
    paste(
      'Kod',
      'mean_distance(graph, directed = TRUE, unconnected = TRUE)',
      '\n',
      'Wynik',
      paste0(round(mean_distance(graphTaskObj(), directed = TRUE, unconnected = TRUE), digits = 3), collapse = ' ')
      ,sep = '\n')
  })
  #------- tasks: shortest paths
  output$shortPath_txt <- renderText({
    paste(
      'Kod',
      'shortest_paths(graph, from, to = V(graph), mode = c("out", "all", "in"),
      weights = NULL, output = c("vpath", "epath", "both"),
      predecessors = FALSE, inbound.edges = FALSE)',
      '\n',
      'Wynik',
      paste0(shortest_paths(graphTaskObj(),from = 1, output = 'vpath')$vpath, collapse = ' ')
      ,sep = '\n')
  })
  #------- tasks: shortest paths
  output$diameter_txt <- renderText({
    paste(
      'Kod',
      'diameter(graph, directed = TRUE, unconnected = TRUE, weights = NULL)',
      '\n',
      'Wynik',
      paste0(diameter(graphTaskObj()), collapse = ' ')
      ,sep = '\n')
  })
  #------- tasks: triangles count
  output$triangle_txt <- renderText({
    paste(
      'Kod',
      'count_triangles(graph, vids = V(graph))',
      '\n',
      'Wynik',
      paste0(count_triangles(graphTaskObj()), collapse = ' ')
      ,sep = '\n')
  })
  #------- tasks: centrality betweenness
  output$centBetw_txt <- renderText({
    if(!is.null(graphDataVer())){
      paste(
      'Kod',
      'centr_betw(graph, directed = TRUE, nobigint = TRUE, normalized = TRUE)',
      '\n',
      'Wynik',
      paste0(round(centr_betw(graphDataVer(), directed = TRUE, nobigint = TRUE, normalized = FALSE)$res,digits = 3),collapse = ' '),
      sep = '\n')
    }else{
      paste(
      'Kod',
      'centr_betw(graph, directed = TRUE, nobigint = TRUE, normalized = TRUE)',
      sep = '\n')
    }
  })  
  #------- tasks: edge betweenness
  output$edgeBetw_txt <- renderText({
    if(!is.null(graphDataVer())){
      paste(
      'Kod',
      'edge_betweenness(graph, e = E(graph), directed = TRUE, weights = NULL)',
      '\n',
      'Wynik',
      paste0(round(edge_betweenness(graphDataVer(), directed = TRUE, weights = NULL),digits = 3),collapse = ' '),
      sep = '\n')
    }else{
      paste(
      'Kod',
      'edge_betweenness(graph, e = E(graph), directed = TRUE, weights = NULL)',
      sep = '\n')
    }
  })  
  #------- tasks: closeness
  output$closeness_txt <- renderText({
    if(!is.null(graphDataVer())){
      paste(
      'Kod',
      'closeness(graph, vids = V(graph), mode = c("out", "in", "all", "total"),weights = NULL, normalized = FALSE)',
      '\n',
      'Wynik',
      paste0(round(round(closeness(graphDataVer(),normalized = FALSE), digits = 3),digits = 3),collapse = ' ')
      ,sep = '\n')
    }else{
      paste(
      'Kod',
      'closeness(graph, vids = V(graph), mode = c("out", "in", "all", "total"),weights = NULL, normalized = FALSE)'
      ,sep = '\n')
    }
  })
  #------- tasks: entropy
  output$entropy_txt <- renderText({
    paste(
      'Kod',
      'diversity(graph, weights = NULL, vids = V(graph))',
      '\n',
      'Wynik',
      paste0(diversity(graphTaskObj(), weights = rep(1,length(E(graphTaskObj())))),collapse = ' ')
      ,sep = '\n')
  })
  #------- tasks: max cliques
  output$cliques_txt <- renderText({
    paste(
      'Kod',
      'max_cliques(graph, min = NULL, max = NULL, subset = NULL, file = NULL)',
      '\n',
      'Wynik',
      paste0(max_cliques(graphTaskObj()), collapse = ' ')
      ,sep = '\n')
  })
  #------- tasks: coreness
  output$coreness_txt <- renderText({
    paste(
      'Kod',
      'coreness(graph, mode = c("all", "out", "in"))',
      '\n',
      'Wynik',
      paste0(coreness(graphTaskObj()), collapse = ' ')
      ,sep = '\n')
  })
  #------- tasks: similarity
  output$similarity_txt <- renderText({
    paste(
      'Kod',
      'similarity(graph, vids = V(graph), mode = c("all", "out", "in", "total"),
       loops = FALSE, method = c("jaccard", "dice", "invlogweighted"))',
      '\n','\n')
  })
  output$similarity_mat <- DT::renderDataTable(options = list(dom = 't', pageLength = 100, scrollX = TRUE),{
    round(similarity(graphTaskObj()), digits = 3)
  })
  #------- uploaded graph
  graphData <- reactive({
    if(is.null(input$graphInput)){
      return(NULL)  
    }else if(!is.null(input$graphInput)){
      G <- as.undirected(read.graph(input$graphInput$datapath, format = 'gml'))
      G
    }
  })
  graphDataVer <- reactive({
    if(is.null(input$graphVerInput)){
      return(NULL)  
    }else if(!is.null(input$graphVerInput)){
      G <- as.undirected(read.graph(input$graphVerInput$datapath, format = 'gml'))
      G
    }
  })
  #------- modularity txt
  output$modularity_txt <- renderText({
    'modularity(x, membership, weights = NULL, ...)'
  })
  #-- louvain clustering
  output$louvainGraph <- renderVisNetwork({
    if(!is.null(graphData())){
      G <- graphData()
      
      if(input$louvainClustIf == 1){
        G.clust <- cluster_louvain(G)
        V(G)$color <- membership(G.clust)
        visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)%>% 
        visLegend(main = paste0('Modularność: ',round(modularity(G.clust), digits = 3)))
      }else{
        visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)
      }
    }else{
      NULL
    }
  })
  output$louvainGraph_txt <- renderText({
    if(input$louvainClustIf == 1){
      G.clust <- cluster_louvain(graphData())
      paste(
      paste0("G <- read.graph(",input$graphInput$datapath,", format = 'gml')"),
      "G.clust <- cluster_louvain(G)",
      "V(G)$color <- membership(G.clust)",
      "visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE) %>% ",
      paste0("visLegend(main = paste0('Modularność: ',round(",modularity(G.clust),", digits = 3)))"),
      sep = '\n')
    }else{
      paste(
      paste0("G <- read.graph(",input$graphInput$datapath,", format = 'gml')"),
      "visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)",
      sep = '\n')
    }
    
  })
  #-- walktrap clustering
  output$walktrapGraph <- renderVisNetwork({
    if(!is.null(graphData())){
      G <- graphData()
      
      if(input$walktrapClustIf == 1){
        G.clust <- cluster_walktrap(G, steps = as.numeric(input$walktrapSteps))
        V(G)$color <- membership(G.clust)
        visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)%>% 
        visLegend(main = paste0('Modularność: ',round(modularity(G.clust), digits = 3)))
      }else{
        visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)
      }
    }else{
      NULL
    }
  })
  output$walktrapGraph_txt <- renderText({
    if(input$walktrapClustIf == 1){
      G.clust <- cluster_walktrap(graphData(),steps = as.numeric(input$walktrapSteps))
      paste(
        paste0("G <- read.graph(",input$graphInput$datapath,", format = 'gml')"),
        "G.clust <- cluster_walktrap(G,",as.numeric(input$walktrapSteps),",)",
        "V(G)$color <- membership(G.clust)",
        "visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE) %>% ",
        "visLegend(main = paste0('Modularność: ',round(",modularity(G.clust),", digits = 3)))",
        sep = '\n')
    }else{
      paste(
        paste0("G <- read.graph(",input$graphInput$datapath,", format = 'gml')"),
        "visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)",
        sep = '\n')
    }
    
  })
  #-- edge clustering
  output$edgeGraph <- renderVisNetwork({
    if(!is.null(graphData())){
      G <- graphData()
      
      if(input$edgeClustIf == 1){
        G.clust <- cluster_edge_betweenness(G)
        V(G)$color <- membership(G.clust)
        E(G)$color <- rep('blue',length(E(G)))
        E(G)$color[G.clust$removed.edges[G.clust$bridges-1]] <- 'red'
        visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)%>% 
        visLegend(main = paste0('Modularność: ',round(modularity(G.clust), digits = 3)))
      }else{
        visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)
      }
    }else{
      NULL
    }
  })
  output$edgeGraph_txt <- renderText({
    if(input$walktrapClustIf == 1){
      G.clust <- cluster_edge_betweenness(graphData())
      paste(
        paste0("G <- read.graph(",input$graphInput$datapath,", format = 'gml')"),
        "G.clust <- cluster_edge_betweenness(G)",
        "V(G)$color <- membership(G.clust)",
        "E(G)$color <- rep('blue',length(E(G)))",
        "E(G)$color[G.clust$removed.edges[G.clust$bridges-1]] <- 'red'",
        "visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE) %>% ",
        "visLegend(main = paste0('Modularność: ',round(",modularity(G.clust),", digits = 3)))",
        sep = '\n')
    }else{
      paste(
        paste0("G <- read.graph(",input$graphInput$datapath,", format = 'gml')"),
        "visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)",
        sep = '\n')
    }
    
  })
  
  #-- graph elements ranking
  output$graphVer <- renderVisNetwork({
    if(!is.null(graphDataVer())){
      stat.ind <- as.numeric(input$graphStat)
      G <- graphDataVer()
      E(G)$color <- 'black'
      if(stat.ind  == 1){
        ramp <- colorRamp(c('green','red'))
        kol <- rgb( ramp(seq(0, 1, length = length(V(G)))), max = 255)
        verStat <- degree(G)
        V(G)$color <- kol[rank(verStat)]
      }else if(stat.ind  == 2){
        ramp <- colorRamp(c('green','red'))
        kol <- rgb( ramp(seq(0, 1, length = length(V(G)))), max = 255)
        verStat <- closeness(G,normalized = FALSE)
        V(G)$color <- kol[rank(verStat)]
      }else if(stat.ind  == 3){
        ramp <- colorRamp(c('green','red'))
        kol <- rgb( ramp(seq(0, 1, length = length(V(G)))), max = 255)
        verStat <- centr_betw(G, directed = TRUE, nobigint = TRUE, normalized = TRUE)
        V(G)$color <- kol[rank(verStat$res)]
      }else if(stat.ind  == 4){
        ramp <- colorRamp(c('green','red'))
        kol <- rgb( ramp(seq(0, 1, length = length(E(G)))), max = 255)
        edgStat <- edge_betweenness(G, directed = TRUE, weights = NULL)
        E(G)$color <- kol[rank(edgStat)]
        E(G)$width <- 5
      }
      visIgraph(G, smooth = TRUE) %>% visOptions(highlightNearest = TRUE)
    }else{
      NULL
    }
  })
  #-- table with elements ranking
  output$graphVerTab <- DT::renderDataTable({
    if(!is.null(graphDataVer())){
      G <- graphDataVer()
      
      x <- order(degree(G), decreasing = TRUE)
      y <- order(closeness(G,normalized = FALSE), decreasing = TRUE)
      z <- order(centr_betw(G, directed = TRUE, nobigint = TRUE, normalized = TRUE)$res, decreasing = TRUE)
      D <- data.frame(x,y,z)
      colnames(D) <- c('Stopień','Closness','Betweenness')
      D
    }else{
      NULL
    }
  })
  
})

