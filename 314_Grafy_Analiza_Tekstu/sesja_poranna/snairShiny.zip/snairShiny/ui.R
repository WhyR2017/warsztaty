library('shinydashboard')
library('DT')
library('visNetwork')
dashboardPage(
  header <- dashboardHeader(
    title = "SNA"
  ),
  
  sidebar <- dashboardSidebar(
    menuItem("Intro", tabName = "intro01", icon = icon("hand-spock-o"),
      menuSubItem("Hello", tabName = "intro02"), # o mnie
      menuSubItem("Biblioteki", tabName = "intro03"), # uzyte pakiety i opis
      menuSubItem("Opis dziedziny", tabName = "intro04"), # co to sna     
      menuSubItem("Grafy - wprowadzenie", tabName = "grafy02", selected = TRUE)
      #### PRZYKLADOWE SIECI SPOLECZNE: FB
    ),
    menuItem("Rodzaje sieci", tabName = "socGraf01", icon = icon("info"),
      menuSubItem("Graf losowy", tabName = "socGraf02"),
      menuSubItem("Small world", tabName = "socGraf03"),
      menuSubItem("Scale-free", tabName = "socGraf04"),
      menuSubItem("Graf dwudzielny", tabName = "socGraf05"),
      menuSubItem("Graf cytowań", tabName = "socGraf06"),
      menuSubItem("Grafy skupień", tabName = "socGraf07"),
      menuSubItem("Drzewa", tabName = "socGraf08")
      # uzupelnic
    ),
    menuItem("Najczęstsze analizy", tabName = "tasks01", icon = icon("lightbulb-o"),
      menuSubItem("Struktura grafu", tabName = "tasks02"),       
      menuSubItem("Analiza skupień", tabName = "tasks03"),
      menuSubItem("Ocena elementów sieci", tabName = "tasks04"),
      menuSubItem("Systemy rekomendacyjne", tabName = "tasks05"),
      #menuSubItem("Bonus - planowanie pracy", tabName = "tasks06"),
      menuSubItem("Zadanie", tabName = "tasks07")
    )
  ),
  ### POWIEDZIEC O LINK PREDICTION
  
  body <- dashboardBody(
    #- layout
    tags$head(
      tags$link(rel = "stylesheet", type = "text/css", href = "snairCSS.css")
    ),
    tabItems(
      #- krotkie przedtawienie sie prowadzacego
      tabItem(tabName = "intro02",
        fluidRow(align = 'center',
          br(),br(),br(),
          h1('Social Network Analysis w R', style = "font-family: Arial"),
          br(),br(),br(),br(),
          h3('Michał Wojtasiewicz', style = "font-family: Arial"),
          h3('Instytut Podstaw Informatyki', style = "font-family: Arial"),
          h3('Polskiej Akademii Nauk', style = "font-family: Arial")
        )        
      ),
      #- krotki opis pakietow
      tabItem(tabName = "intro03",
        fluidRow(align = 'center',
          withMathJax(),
          br(),br(),
          h1(tags$b('igraph'), style = "font-family: Arial"),
          h3('Pakiet zawierający zbiór funkcji do operacji na grafach, także na dużych.
             Istnieje też wersja w języku Python. 
             Licencja GPL\\(\\geq\\)2', style = "font-family: Arial"),               
          br(),
          h1(tags$b('Matrix'), style = "font-family: Arial"),
          h3('Pakiet wprowadzający macierze rzadkie. Licencja GPL\\(\\geq\\)2', style = "font-family: Arial"),
          br(),
          h1(tags$b('visNetwork'), style = "font-family: Arial"),
          h3("Pakiet do wizualizacji grafów jako API do 'vis.js'. Licencja MIT oraz plik License", style = "font-family: Arial")
          # przeczytac od licencjach
        )
        # helpText('An irrational number \\(\\frac{2}{3} \\sqrt{4}\\) and a fraction $$1-\\frac{1}{2}$$')           
      ),
      tabItem(tabName = "intro04",
        fluidRow(align = 'center',
          h3("Social Network Analysis czyli analiza sieci społecznych/społecznościowych", style = "font-family: Arial"),
          br(),
          h3('Wikipedia:', tags$i('Badania sieci społecznej i stosunków społecznych, wykorzystujące teorię grafów i koncentrujące się na analizie stosunków pomiędzy elementami sieci (jednostkami, organizacjami itp.) W analizie sieciowej nacisk kładzie się na relacje i ich wzorce, z których wynikają szanse i ograniczenia dla węzłów sieci.'), style = "font-family: Arial"),
          h3("Należy zdawać sobie sprawę, że techniki użyte w przypadku sieci społecznych są skuteczne
             w przypadku dowolnych sieci, ale trzeba pamiętać o właściwej interpretacji!", style = "font-family: Arial")
        ),
        fluidRow(align = 'center',
          h3("Naturalną metodą reprezentacji i analizy sieci społecznych jest graf", style = "font-family: Arial"),
          column(6,
            sliderInput('graphDef_ver', 'Liczba wierzchołków', min = 2, max = 100, value = 5, step = 1)
          ),
          column(6,
            sliderInput('graphDef_edg', 'Liczba krawędzi', min = 1, max = 500, value = 5, step = 1)#,
            #verbatimTextOutput('graphDef_txt')
          ),
          visNetworkOutput('graphDef', height = '600px')
        )    
      ),
      tabItem(tabName = "grafy02",
        fluidRow(align = 'left',
          h1(tags$b('Definicja grafu'), style = "font-family: Arial"),
          br(),
          h2('Intuicja:', style = "font-family: Arial"),
          h2('W przypadku badania sieci społecznych mamy do czynienia z grupą elementów między którymi istnieje (bądź nie) konkretny rodzaj powiązania.
              Intuicyjnie na czas analizy każdemu elementowi należy przypisać numer,
              natomiast każde dwa elementy między którymi występuje powiązanie należy
              połączyć odcinkiem - krawędzią.', style = "font-family: Arial"),
          h2('Tak utworzoną strukturę nazywa się grafem.', style = "font-family: Arial"),
          withMathJax(),
          br(),
          br(),
          h2('Formalnie:', style = "font-family: Arial"),
          h2('Graf składa się z dwóch zbiorów: V(G) - jest niepustym zbiorem wierzchołków, E(G) - jest zbiorem krawędzi.', style = "font-family: Arial"),
          br(),
          h2('V(G) = {\\(\\\\v_{1}\\),\\(\\\\v_{2}\\),...,\\(\\\\v_{n}\\)}', style = "font-family: Arial", align = 'center'),
          h2('E(G) = {\\(\\\\e_{1}\\),\\(\\\\e_{2}\\),...,\\(\\\\e_{m}\\)}, gdzie \\(\\\\e_{1}\\) = {\\(\\\\v_{k}\\),\\(\\\\v_{l}\\)}', style = "font-family: Arial", align = 'center')
        ),
        fluidRow(align = 'left',
          br(),
          h1(tags$b('Rodzaje grafów'), style = "font-family: Arial"),
          h2(tags$b('Graf prosty'), ' - krawędzie nie mają kierunku, między każdymi dwoma wierzchołkami istnieje co najwyżej jedna krawędź,
              krawędź składa się z dwóch różnych wierzchołków.', style = "font-family: Arial"),
          h2(tags$b('Graf prosty skierowany'),' - krawędzie mogą mieć kierunek, między każdymi dwoma wierzchołkami istnieje co najwyżej jedna krawędź,
             krawędź składa się z dwóch różnych wierzchołków.', style = "font-family: Arial"),
          h2(tags$b('Graf ogólny/multigraf'),' - krawędzie mogą mieć kierunek, między każdymi dwoma wierzchołkami istnieje dowolna liczba krawędzi,
             krawędź może tworzyć pętlę.', style = "font-family: Arial"),
          h2('Uwagi', style = "font-family: Arial"),
          h2('1) Każdy wierzchołek oraz krawędź może posiadać wagę. Mówimy wtedy o grafie ważonym.', style = "font-family: Arial"),
          h2('2) Liczbę krawędzi wchodzących/wychodzących z wierzchołka nazywamy jego stopniem i oznaczamy deg(v).', style = "font-family: Arial"),
          h2('3) Sąsiedztwem stopnia k wierzchołka v nazywa się wierzchołek v oraz wierzchołki, odległego o co najwyżej k kroków.', style = "font-family: Arial"),
          h2('4) Ciąg sąsiadujących ze sobą wierzchołków nazywamy ścieżką.', style = "font-family: Arial"),
          h2('5) Cyklem nazywamy ciąg wierzchołków gdzie pierwszy i ostatni element są takie same.', style = "font-family: Arial"),
          column(3,
            sliderInput('graphDesc_ver', 'Liczba wierzchołków', min = 2, max = 10, value = 5, step = 1)       
          ),
          column(3,
            sliderInput('graphDesc_edg', 'Liczba krawędzi', min = 1, max = 50, value = 5, step = 1)                        
          ),
          column(3,
            selectInput('graphDesc_ifLoops', 'Czy pętle?', choices = list('NIE' = 0, 'TAK' = 1))       
          ),
          column(3,
            selectInput('graphDesc_ifDirected', 'Czy skierowany?', choices = list('NIE' = 0, 'TAK' = 1))       
          ),
          column(7,
            visNetworkOutput('graphDesc', height = '600px')
          ),
          fluidRow(
            column(5, align = 'left',
              h3(tags$i('Istnieją dwie główne metody zapisu grafu: macierz sąsiedztwa oraz lista krawędzi.', style = "font-family: Arial")),
              tabsetPanel(
                tabPanel('Macierz sąsiedztwa',
                  dataTableOutput('graphDesc_mat', width = '30%') 
                ),
                tabPanel('Lista krawędzi',
                  dataTableOutput('graphDesc_edgLst', width = '30%')
                )
              )      
            )
          )
        )
      ),
      tabItem(tabName = "socGraf02",
        h1(tags$b('Graf losowy')),
        h2('Grafem losowym nazywamy graf, 
           w ktorym nie istnieją żadne charakterystyczne struktury oraz powiązania.', style = "font-family: Arial"),
        fluidRow(
          column(3,
            sliderInput('graphRandom_ver', 'Liczba wierzchołków', min = 2, max = 100, value = 5, step = 1)       
          ),
          column(3,
            sliderInput('graphRandom_edg', 'Liczba krawędzi', min = 1, max = 500, value = 5, step = 1)                        
          )
        ),
        fluidRow(
          column(8,
            visNetworkOutput('graphRandom')       
          ),
          column(4,
            verbatimTextOutput('graphRandom_txt'),
            plotOutput('graphRandomDegHist')     
          )
        )
      ),
      tabItem(tabName = "socGraf03",
        h1(tags$b('Graf small-world')),
        h2('Graf z własnością small-world charakteryzuje się tym, że jeśli wierzchołek A jest
           połączony z wierzchołkiem B i C to zwykle wierzchołki B i C też są ze sobą połączone. Innymi słowy
           graf w dużej mierze składa się z trójkątów.', style = "font-family: Arial"),
            fluidRow(
            column(4,
              sliderInput('graphSmallWorld_ver', 'Liczba wierzchołków', min = 2, max = 100, value = 5, step = 1)       
            ),
            column(4,
              sliderInput('graphSmallWorld_neigh', 'Stopień sąsiedztwa', min = 1, max = 5, value = 1, step = 1)                        
            ),
            column(4,
              sliderInput('graphSmallWorld_rewire', 'Losowość', min = 0, max = 1, value = 0.1, step = 0.1)                        
            )
          ),
          fluidRow(
          column(8,
            visNetworkOutput('graphSmallWorld')       
          ),
          column(4,
            verbatimTextOutput('graphSmallWorld_txt'),
            plotOutput('graphSmallWorldDegHist')     
          )
        )
      ),
      tabItem(tabName = "socGraf04",
        h1(tags$b('Graf scale-free')),
        h2('Graf typ scale-free charakteryzuje się silnie skośnym rozkładem stopni wierzchołków. Odzwierciedla w ten
           sposób sytuację, w której nowo powstałe połączenia powstają zwykle przy udziale wierzchołków o najwyższym stopniu.', style = "font-family: Arial"),
            fluidRow(
            column(4,
              sliderInput('graphPA_ver', 'Liczba wierzchołków', min = 2, max = 100, value = 5, step = 1)       
            ),
            column(4,
              sliderInput('graphPA_edg', 'Liczba krawędzi dodanych w każdym kroku', min = 1, max = 5, value = 1, step = 1)                        
            ),
            column(4,
              sliderInput('graphPA_power', 'Skośność', min = 1, max = 10, value = 1, step = 1)                        
            )
          ),
          fluidRow(
          column(8,
            visNetworkOutput('graphPA')       
          ),
          column(4,
            verbatimTextOutput('graphPA_txt'),
            plotOutput('graphPADegHist')     
          )
        )
      ),
      tabItem(tabName = "socGraf05",
        h1(tags$b('Graf dwudzielny')),
        h2('Graf dwudzielny jest to graf, w którym krawędzie występują tylko między wierzchołkami z różnych klas.', style = "font-family: Arial"),
          fluidRow(
            column(4,
              sliderInput('graphBipartite_1class', 'Liczba wierzchołków w 1. klasie', min = 2, max = 100, value = 5, step = 1)       
            ),
            column(4,
              sliderInput('graphBipartite_2class', 'Liczba wierzchołków w 2. klasie', min = 2, max = 100, value = 1, step = 1)                        
            ),
            column(4,
              sliderInput('graphBipartite_edg', 'Liczba krawędzi', min = 1, max = 1000, value = 2, step = 1),
              selectInput('graphBipartite_ifCol', 'Pokolorować klasy?', choices = list('NIE' = 0, 'TAK' = 1), selected = 0)                        
            )
          ),
          fluidRow(
            column(8,
              visNetworkOutput('graphBipartite')       
            ),
          column(4,
            verbatimTextOutput('graphBipartite_txt'),
            plotOutput('graphBipartiteDegHist')     
          )
        )
      ),
      tabItem(tabName = "socGraf06",
        h1(tags$b('Graf cytowań'), style = "font-family: Arial"),
        h2('Graf skierowany gdzie wierzchołkami są obiekty odwołujące się do siebie - ukryta zależność w czasie.', style = "font-family: Arial"),
        fluidRow(
          column(4,
            sliderInput('graphCite_ver', 'Liczba wierzchołków', min = 1, max = 100, value = 5, step = 1)       
          ),
          column(4,
            sliderInput('graphCite_edg', 'Liczba krawędzi', min = 1, max = 500, value = 1, step = 1)                        
          )
        ),
        fluidRow(
          column(8,
            visNetworkOutput('graphCite')       
          ),
          column(4,
            verbatimTextOutput('graphCite_txt'),
            plotOutput('graphCiteDegHist')     
          )
        )
      ),
      tabItem(tabName = "socGraf07",
        h1(tags$b('Graf skupień'), style = "font-family: Arial"),
        h2('Graf składający się z grup wierzchołków. Większość krawędzi występuje wewnątrz grup.', style = "font-family: Arial"),
        fluidRow(
          column(3,
            sliderInput('graphClust_clust', 'Liczba skupień', min = 1, max = 10, value = 3, step = 1)       
          ),
          column(3,
            sliderInput('graphClust_ver', 'Liczba wierzchołków', min = 1, max = 20, value = 1, step = 1)                        
          ),
          column(3,
            sliderInput('graphClust_edgProb', 'Prawdopodobieństwo wystąpienia krawędzi', min = 0, max = 1, value = 0.5, step = 0.1)       
          ),
          column(3,
            sliderInput('graphClust_edgBetCnt', 'Liczba krawędzi między skupieniami', min = 1, max = 10, value = 1, step = 1),
            selectInput('graphClust_ifCol', 'Pokolorować skupienia?', choices = list('NIE' = 0, 'TAK' = 1), selected = 0)                        
            
          )
        ),
        fluidRow(
          column(8,
            visNetworkOutput('graphClust')       
          ),
          column(4,
            verbatimTextOutput('graphClust_txt'),
            plotOutput('graphClustDegHist')     
          )
        )
      ),
      tabItem(tabName = "socGraf08",
        h1(tags$b('Drzewo')),
        h2('Graf o strukturze drzewa.', style = "font-family: Arial"),
        fluidRow(
          column(3,
            sliderInput('graphTree_ver', 'Liczba wierzchołków', min = 1, max = 20, value = 3, step = 1)       
          ),
          column(3,
            sliderInput('graphTree_deg', 'Liczba potomków', min = 2, max = 6, value = 2, step = 1)                        
          )
        ),
        fluidRow(
          column(8,
            visNetworkOutput('graphTree')       
          ),
          column(4,
            verbatimTextOutput('graphTree_txt'),
            plotOutput('graphTreeDegHist')     
          )
        )
      ),
      tabItem(tabName = "tasks02",
        fluidRow(
          column(8,
            tabsetPanel(
              tabPanel(title = 'Rozkład stopni wierzchołków',
                verbatimTextOutput('degree_txt'),
                  tags$head(tags$style(HTML("
                            #degree_txt {
                              font-size: 20px;
                            }
                            ")))
              ),
              # sasiedztwo
              tabPanel(title = 'Średnia odległość',
                verbatimTextOutput('meanDist_txt'),
                                   tags$head(tags$style(HTML("
                                                             #meanDist_txt {
                                                             font-size: 20px;
                                                             }
                                                             ")))
              ),
              tabPanel(title = 'Najkrótsze ścieżki',
                verbatimTextOutput('shortPath_txt'),
                                   tags$head(tags$style(HTML("
                                                             #shortPath_txt {
                                                             font-size: 20px;
                                                             }
                                                             ")))
              ),
              tabPanel(title = 'Średnica',
                verbatimTextOutput('diameter_txt'),
                                   tags$head(tags$style(HTML("
                            #diameter_txt {
                              font-size: 20px;
                            }
                            ")))
              ),
              tabPanel(title = 'Liczba trójkątów',
                verbatimTextOutput('triangle_txt'),
                                   tags$head(tags$style(HTML("
                            #triangle_txt {
                              font-size: 20px;
                            }
                            ")))
              ),
              tabPanel(title = 'Kliki',
                verbatimTextOutput('cliques_txt'),
                                   tags$head(tags$style(HTML("
                                                             #cliques_txt {
                                                             font-size: 20px;
                                                             }
                                                             ")))
              ),
              tabPanel(title = 'Coreness',
                verbatimTextOutput('coreness_txt'),
                                   tags$head(tags$style(HTML("
                            #coreness_txt {
                              font-size: 20px;
                            }
                            ")))
              ),
              tabPanel(title = 'Similarity',
                verbatimTextOutput('similarity_txt'),
                                   tags$head(tags$style(HTML("
                            #similarity_txt {
                              font-size: 20px;
                            }
                            "))),
                dataTableOutput('similarity_mat')
              )
            )
          ),
          column(4,
            shinydashboard::box(width = '100%',
              column(4,
                sliderInput('graphTask_ver', 'Liczba wierzchołków', min = 2, max = 100, value = 10, step = 1)       
              ),
              column(4,
                sliderInput('graphTask_edg', 'Stopień sąsiedztwa', min = 1, max = 6, value = 1, step = 1)                        
              ),
              column(4,
                sliderInput('graphTask_prob', 'Losowość', min = 0, max = 1, value = 0.1, step = 0.05)                        
              ),
              visNetworkOutput('graphTask'),
              verbatimTextOutput('graphTask_txt'),
              tags$head(tags$style(HTML(" #graphTask_txt {
                                          font-size: 20px;
                                          }")))
            )
          )
        )
      ),
      tabItem(tabName = "tasks03",
              h1(tags$b('Analiza skupień'), style = "font-family: Arial"),     
              h2('Jest to grupa metod uczenia bez nadzoru. Polega na identyfikacji grup elementów,
                 które są sobie bliskie. W grafach bliskość definiuje się poprzez liczbę połączeń
                 między wierzchołkami.', style = "font-family: Arial"),
              h2('Skupieniem określa się grupę wierzchołków, w której liczba krawędzi wewnątrz grupy
                 jest znacząco wyższa niż liczba krawędzi wychodzących do innych grup.', style = "font-family: Arial"),
              h2("Liczba wszystkich możliwych podziałów grafu jest tzw. liczbą Bella.
                 Dla n= 5 : B = 52, n = 10 : B = 102247563.", style = "font-family: Arial"),
        br(),
        h1(tags$b('Modularność', style = "font-family: Arial")),
        withMathJax(),
        h2('Jest to napopularniejsza miara służąca do oceny jakości podziału na skupienia.', style = "font-family: Arial"),
        h2('Q = \\(\\frac{1}{2m}\\sum_{i,j}(A_{ij} - \\frac{k_{i}k_{j}}{2m})\\delta(i,j) \\)', align = 'center', style = "font-family: Arial"),
        h2(verbatimTextOutput('modularity_txt'), align = 'center'),
        tags$head(tags$style(HTML(" #modularity_txt {
                                          font-size: 20px;
                                          }"))),
        br(),
        fluidRow(align = 'center',
          fileInput("graphInput", label = h3("Wczytaj graf"), buttonLabel = "Find", width = "40%")
        ),
        tabsetPanel(
          tabPanel(tags$b('Algorytm Louvain', style = "font-family: Arial"),
            fluidRow(
              h2('Jest to zachłanny algorytm hierarchiczny. W każdym kroku łączy grupy wierzchołków
                 maksymalizując modularność.', style = "font-family: Arial"),           
              column(5,
                selectInput('louvainClustIf','Wyznaczyć skupienia?', choices = list('NIE' = 0,'TAK' = 1), selected = 0),
                verbatimTextOutput('louvainGraph_txt'),
                tags$head(tags$style(HTML(" #louvainGraph_txt {
                                          font-size: 20px;
                                          }")))
              ),
              column(7,
                visNetworkOutput('louvainGraph', height = '600px')
              )
            )
          ),
          tabPanel(tags$b('Algorytm Walktrap'),
            fluidRow(
              h2('Algorytm oparty na błądzeniu losowym. Bliskość między wierzchołkami
                 określa się symulując krótkie błądzenia losowe.', style = "font-family: Arial"),
              column(5,
                selectInput('walktrapClustIf','Wyznaczyć skupienia?', choices = list('NIE' = 0,'TAK' = 1), selected = 0),
                sliderInput('walktrapSteps', 'Liczba kroków', min = 1, max = 10, value = 1, step = 1),
                verbatimTextOutput('walktrapGraph_txt'),
                tags$head(tags$style(HTML(" #walktrapGraph_txt {
                                          font-size: 20px;
                                          }")))
              ),
              column(7,
                visNetworkOutput('walktrapGraph')
              )
            )
          ),
          tabPanel(tags$b('Algorytm Edge Betweenness'),
            fluidRow(
              h2('Jest to zachłanny algorytm hierarchiczny. W każdym kroku usuwa krawędź, która uczestniczy w największej liczbie najkrótszych ścieżek.', style = "font-family: Arial"),           
              column(5,
                selectInput('edgeClustIf','Wyznaczyć skupienia?', choices = list('NIE' = 0,'TAK' = 1), selected = 0),
                verbatimTextOutput('edgeGraph_txt'),
                tags$head(tags$style(HTML(" #edgeGraph_txt {
                                          font-size: 20px;
                                          }")))
              ),
              column(7,
                visNetworkOutput('edgeGraph')
              )
            )
          )
        )
      ),
      tabItem(tabName = "tasks04",
        fluidRow(align = 'center',
          fileInput("graphVerInput", label = h3("Wczytaj graf"), buttonLabel = "Find", width = "40%")        
        ),
        fluidRow(
          column(6,
            h1('Identyfikacja kluczowych wierzchołków', style = "font-family: Arial"),
            h2('Stopień wierzchołka', style = "font-family: Arial"),
            h3('Intuicyjnie stopień wierzchołka odzwierciedla "popularność" danego elementu w sieci. Czyli mówi o tym jak wiele
                osób/obiektów ma bezpośredni dostęp do wierzchołka.', style = "font-family: Arial"),
            verbatimTextOutput('degree_txt1'),
            tags$head(tags$style(HTML(" #degree_txt1 {
                                          font-size: 20px;
                                          }"))),     
            
            h2('Closeness', style = "font-family: Arial"),
            h3('Współczynnik bliskości opisuje jak szybko dany wierzchołek
               może skomunikować się z dowolnym innym wierzchołkiem w grafie.', style = "font-family: Arial"),
            verbatimTextOutput('closeness_txt'),
            tags$head(tags$style(HTML(" #closeness_txt {
                                          font-size: 20px;
                                          }"))),
                 
            h2('Betweeness Centrality', style = "font-family: Arial"),
            h3('Ten współczynnik opisuje jak często przechodząc po krawędziach w sieci
               będziemy przechodzić przez dany wierzchołek.', style = "font-family: Arial"),
            verbatimTextOutput('centBetw_txt'),
            tags$head(tags$style(HTML(" #centBetw_txt {
                                          font-size: 20px;
                                          }"))),
                 
            h1('Identyfikacja kluczowych krawędzi'),       
            h2('Edge Betweeness', style = "font-family: Arial"),
            h3('Współczynnik określa jak często przechodząc po grafie będziemy przechodzić przez daną krawędź.', style = "font-family: Arial"),
                verbatimTextOutput('edgeBetw_txt'),
                tags$head(tags$style(HTML(" #edgeBetw_txt {
                                          font-size: 20px;
                                          }")))       
          ),
          column(6,
            selectInput('graphStat', 'Statystyka', choices = list('Żadna' = 0,'Stopień' = 1, "Closeness" = 2, "Betweeness Centrality" = 3, "Edge Betweeness" = 4), selected = 0),
            visNetworkOutput('graphVer'),
            dataTableOutput('graphVerTab')
          )
        )
        
      ),
      tabItem(tabName = "tasks05",
        h1(tags$b('System rekomendacyjny'), style = "font-family: Arial"),
        h2('Jest to sieć, która ma postać grafu dwudzielnego. Jedna klasa to produkty (np. filmy, książki), natomiast drugą
           klasę stanowią użytkownicy, którzy nabywają dany produkt.', style = "font-family: Arial"),
        h2(tags$b('Zadanie'),': określić, którzy użytkownicy kupują podobne przedmioty.', style = "font-family: Arial"),
        h2(tags$b('Cel'),': rekomendowanie przedmiotów użytkownikom, kierowanie kampanii marketingowych, 
           ocena portfela klientów, itp.', style = "font-family: Arial"),
        br(),
        h2(tags$b('Collaborative filtering'), style = "font-family: Arial"),
        tabsetPanel(
          tabPanel('Teoria',
            h3('Jest to grupa technik polegająca na określeniu jak bardzo dany przedmiot może interesować badanego użytkownika.', style = "font-family: Arial"),
            h3('1. Określanie podobieństwa między użytkownikami.', style = "font-family: Arial"),
            h3('2. Określanie podobieństwa między przedmiotami.', style = "font-family: Arial"),
            br(),
            h2('Rozwiązanie memory-based', style = "font-family: Arial"),
            h3('Wykorzystanie wybranej odległości: kosinusowej, Jaccarda, współczynnika korelacji,...', style = "font-family: Arial"),
            h3('Wady: sparsity, cold start.', style = "font-family: Arial"),
            br(),
            h2('Rozwiązanie model-based', style = "font-family: Arial"),
            h3('Wykorzystanie techniki uczenia maszynowego: analiza skupień, model Bayesowski, LDA,...', style = "font-family: Arial"),
            h3('Wady: część informacji nie jest wykorzystywana.', style = "font-family: Arial"),
            br(),
            h2('Rozwiązanie hybrydowe', style = "font-family: Arial"),
            h3('Obecnie najbardziej popularne i dające najlepsze rezultaty. Przykładowe zastosowanie: ważenie krawędzi, dodawanie krawędzi między elementami z tej samej klasy. Znany przykład rekomendera: Google News Recommender.', style = "font-family: Arial")
          ),
          tabPanel('Praktyka',
            fluidRow(align = 'center',  
              br(),br(),br(),br(),br(),br(),
              h2('Zapraszam do kodu')
            )  
          )
        )
      ),
      # tabItem(tabName = "tasks06",
      #   h1('Kolorowanie zwarte')
      # ),
      tabItem(tabName = "tasks07",
        fluidRow(
          column(4,
            h1('Zadanie', style = "font-family: Arial"),
            h3('1) Wejść na stronę https://snap.stanford.edu/data/', style = "font-family: Arial"),
            h3('2) Wybrać i ściągnąć graf do analizy', style = "font-family: Arial"),
            h3('3) Wczytać go i określić atrybuty', style = "font-family: Arial"),
            h3('4) Wykonać analizę skupień i określić jakość podziału', style = "font-family: Arial"),
            h3('5) Znaleźć kluczowe wierzchołki', style = "font-family: Arial"),
            h3('6) Znaleźć kluczowe krawędzie', style = "font-family: Arial"),
            h3('7) Wyciągnąć wnioski', style = "font-family: Arial")       
          ),
          column(8,
            h1('Przydatne funkcje', style = "font-family: Arial"),
            h3('01) Wczytanie grafu: read_graph(file, format = c("edgelist", "pajek", "ncol", "lgl", "graphml", "dimacs", "graphdb", "gml", "dl"), ...)', style = "font-family: Arial"),
            h3('02) Graf z listy krawędzi: graph_from_edgelist(el, directed = TRUE)', style = "font-family: Arial"),
            h3('03) Wylistowanie wierzchołków: V(graph)', style = "font-family: Arial"),
            h3('04) Wylistowanie krawędzi: E(graph)', style = "font-family: Arial"),
            h3('05) Nadanie atrybutu koloru do elementu: V(graph)$color', style = "font-family: Arial"),
            h3('06) Nadanie atrybutu wagi do krawędzi: V(graph)$weight', style = "font-family: Arial"),
            h3('07) Algorytm Louvain: cluster_louvain(graph, weights = NULL)', style = "font-family: Arial"),
            h3('08) Stopień wierzchołka: degree(graph, v = V(graph), mode = c("all", "out", "in", "total"),loops = TRUE, normalized = FALSE)', style = "font-family: Arial"),
            h3('09) Closeness: closeness(graph, vids = V(graph), mode = c("out", "in", "all", "total"), weights = NULL, normalized = FALSE)', style = "font-family: Arial"),
            h3('10) Betweenness centrality: centr_betw(graph, directed = TRUE, nobigint = TRUE, normalized = TRUE)', style = "font-family: Arial"),
            h3('11) Edge betweenness: edge_betweenness(graph, e = E(graph), directed = TRUE, weights = NULL)', style = "font-family: Arial"),
            h3('12) Rysowanie grafu: visIgraph(...)', style = "font-family: Arial")
          )
        )              
       
        
        
      )
    )
  ),

  dashboardPage(
    title = "SNA",
    header, 
    sidebar,
    body
  )
)
