library('shiny')
setwd("E:/main/projects/whyR/SNAiR/")
runApp("snairShiny", launch.browser = TRUE)


